import cv2
import serial
import time

# Customize with your name
name = "Simba"

# Initialize the serial connection to Arduino
arduino = serial.Serial('COM3', 9600)  # Change 'COM3' to your Arduino port

# Initialize the webcam
cap = cv2.VideoCapture(0)

def detect_hand_gesture(frame):
    # Convert to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Apply Gaussian blur
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    # Apply thresholding
    _, thresh = cv2.threshold(blur, 60, 255, cv2.THRESH_BINARY_INV)
    # Find contours
    contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        # Get the largest contour
        contour = max(contours, key=cv2.contourArea)
        if cv2.contourArea(contour) > 1000:
            return True  # Hand is detected
    return False

while True:
    ret, frame = cap.read()
    if not ret:
        break

    hand_detected = detect_hand_gesture(frame)
    if hand_detected:
        arduino.write(b'L')  # Send 'L' to Arduino to turn off the light
        print(f"{name} raises hand, light is off")
    else:
        arduino.write(b'H')  # Send 'H' to Arduino to turn on the light
        print(f"{name} opens hands, bulb lights up")

    cv2.imshow('Hand Gesture', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
arduino.close()
